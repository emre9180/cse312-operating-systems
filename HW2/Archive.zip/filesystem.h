#ifndef FILESYSTEM_H
#define FILESYSTEM_H

#include <stdint.h>

#define BLOCK_SIZE 1024  // 1 KB blocks
#define MAX_BLOCKS 4096  // 4 MB file system
#define SUPER_BLOCK_SIZE 1
#define FAT_ENTRY_BITS 12  // 12 bits per entry in FAT12
#define BITS_PER_BYTE 8

// Calculate the total number of bits needed for the FAT
#define FAT_TOTAL_BITS (MAX_BLOCKS * FAT_ENTRY_BITS)

// Convert bits to bytes, and then calculate the number of blocks needed to store the FAT
#define FAT_TOTAL_BYTES ((FAT_TOTAL_BITS + BITS_PER_BYTE - 1) / BITS_PER_BYTE) // Round up to nearest byte
#define FAT_SIZE_BLOCKS ((FAT_TOTAL_BYTES + BLOCK_SIZE - 1) / BLOCK_SIZE) // Round up to nearest block

#define MAX_FILES 128

#define PERMISSION_READ  0x01
#define PERMISSION_WRITE 0x02

typedef struct {
    uint16_t fat[FAT_SIZE_BLOCKS * BLOCK_SIZE / sizeof(uint16_t)];  // Size the FAT in terms of 16-bit entries
} FAT;

typedef struct {
    uint32_t fileNameOffset;  // Offset of the file name within the file system
    uint16_t fileNameLength;  // Length of the file name
    uint32_t size;            // File size
    uint16_t permissions;     // Owner permissions (R and W)
    uint32_t creationDate;    // File creation date
    uint32_t modificationDate; // Last modification date
    char password[32];        // Password protection
    uint16_t firstBlock;      // First block of the file
} DirectoryEntry;

typedef struct {
    DirectoryEntry entries[MAX_FILES];
    uint16_t fileCount;
} DirectoryTable;

typedef struct {
    uint8_t bitmap[MAX_BLOCKS / 8];  // Bitmap to track free blocks
} FreeBlockBitmap;

typedef struct {
    uint32_t offset;    // Offset where file names start
    uint32_t size;      // Size of the file name storage area
    uint32_t used;      // Amount of used space in the file name storage area
} FileNameArea;

typedef struct {
    uint32_t offset;    // Offset to the start of the data segment
    uint32_t size;      // Total size of the data segment
    uint32_t blockCount; // Number of blocks in the data segment
} DataArea;

typedef struct {
    uint16_t blockSize;
    uint16_t totalBlocks;
    uint16_t freeBlocks;
    uint16_t fatBlocks;
    DirectoryTable rootDirectory;
    FreeBlockBitmap freeBlocksBitmap;
    FAT fat;
    FileNameArea fileNameArea; // Struct for file name area
    DataArea dataArea;         // Struct for data area
} SuperBlock;

extern SuperBlock superBlock;
extern char *fsMemoryBase; // Base pointer for file system memory

// Function declarations
void initializeFileSystem(uint16_t blockSize, char *fsBase, int totalFsSize);
void setBlockFree(uint16_t blockNumber);
void setBlockUsed(uint16_t blockNumber);
uint16_t findFreeBlock(char *fsBase);
int createFile(char *fsBase, const char *fileName, uint16_t permissions, const char *password);
int deleteFile(char *fsBase, const char *fileName);

#endif // FILESYSTEM_H