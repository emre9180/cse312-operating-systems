#include "filesystem.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

SuperBlock superBlock;
char *fsMemoryBase; // Base pointer for file system memory

void initializeFileSystem(uint16_t blockSize, char *fsBase, int totalFsSize)
{
    fsMemoryBase = fsBase;                // Set the global file system base pointer
    memset(fsMemoryBase, 0, totalFsSize); // Initialize all memory to zero

    superBlock.blockSize = blockSize;
    superBlock.totalBlocks = MAX_BLOCKS;
    superBlock.freeBlocks = MAX_BLOCKS; // Start with all blocks as free
    superBlock.fatBlocks = FAT_SIZE_BLOCKS;

    // Initialize the bitmap to all free
    memset(superBlock.freeBlocksBitmap.bitmap, 0xFF, sizeof(superBlock.freeBlocksBitmap.bitmap));

    // Set up the FAT
    memcpy(&superBlock.fat, fsMemoryBase + sizeof(SuperBlock), sizeof(FAT));
    
    // Set up the directory table
    superBlock.rootDirectory = *(DirectoryTable *)(fsMemoryBase + sizeof(SuperBlock) + sizeof(FAT) + sizeof(FreeBlockBitmap));

    // Setup filename area
    superBlock.fileNameArea.offset = sizeof(SuperBlock) + sizeof(FAT) + sizeof(DirectoryTable) + sizeof(FreeBlockBitmap);
    superBlock.fileNameArea.size = MAX_FILES * sizeof(DirectoryEntry);
    superBlock.fileNameArea.used = 0;

    // Setup data area
    superBlock.dataArea.offset = superBlock.fileNameArea.offset + superBlock.fileNameArea.size;
    superBlock.dataArea.size = (MAX_BLOCKS * blockSize) - superBlock.dataArea.offset;
    superBlock.dataArea.blockCount = superBlock.dataArea.size / blockSize;

    // Mark system-reserved blocks as used
    for (int i = 0; i < (superBlock.dataArea.offset / blockSize); i++)
    {
        setBlockUsed(i);
    }
}

void setBlockFree(uint16_t blockNumber)
{
    if (blockNumber < MAX_BLOCKS)
    {
        superBlock.freeBlocksBitmap.bitmap[blockNumber / 8] |= (1 << (blockNumber % 8));
        superBlock.freeBlocks++;
    }
}

void setBlockUsed(uint16_t blockNumber)
{
    if (blockNumber < MAX_BLOCKS)
    {
        superBlock.freeBlocksBitmap.bitmap[blockNumber / 8] &= ~(1 << (blockNumber % 8));
        superBlock.freeBlocks--;
    }
}

uint16_t findFreeBlock(char *fsBase)
{
    for (int i = 0; i < MAX_BLOCKS; ++i)
    {
        if (superBlock.freeBlocksBitmap.bitmap[i / 8] & (1 << (i % 8)))
        {
            return i;
        }
    }
    return -1; // No free block found
}

int createFile(char *fsBase, const char *fileName, uint16_t permissions, const char *password)
{
    if (superBlock.rootDirectory.fileCount >= MAX_FILES)
    {
        fprintf(stderr, "Directory full\n");
        return -1;
    }

    uint16_t fileNameLength = strlen(fileName) + 1; // Include null terminator
    if (superBlock.fileNameArea.used + fileNameLength > superBlock.fileNameArea.size)
    {
        fprintf(stderr, "Not enough space for file name\n");
        return -1;
    }

    uint16_t freeBlock = findFreeBlock(fsBase);
    if (freeBlock == (uint16_t)-1)
    {
        fprintf(stderr, "No free blocks available\n");
        return -1;
    }

    DirectoryEntry *newEntry = &superBlock.rootDirectory.entries[superBlock.rootDirectory.fileCount++];
    newEntry->fileNameOffset = superBlock.fileNameArea.used;
    newEntry->fileNameLength = fileNameLength;
    newEntry->size = 0;
    newEntry->permissions = permissions;
    newEntry->firstBlock = freeBlock;
    newEntry->creationDate = time(NULL);
    newEntry->modificationDate = newEntry->creationDate;
    strncpy(newEntry->password, password, sizeof(newEntry->password) - 1);

    char *fileNamePtr = fsMemoryBase + superBlock.fileNameArea.offset + superBlock.fileNameArea.used;
    memcpy(fileNamePtr, fileName, fileNameLength);
    superBlock.fileNameArea.used += fileNameLength;

    setBlockUsed(freeBlock);

    return 0; // Success
}

int deleteFile(char *fsBase, const char *fileName)
{
    for (int i = 0; i < superBlock.rootDirectory.fileCount; i++)
    {
        DirectoryEntry *entry = &superBlock.rootDirectory.entries[i];
        char *storedFileName = fsMemoryBase + superBlock.fileNameArea.offset + entry->fileNameOffset;
        if (strncmp(storedFileName, fileName, entry->fileNameLength) == 0)
        {
            setBlockFree(entry->firstBlock);
            superBlock.fileNameArea.used -= entry->fileNameLength; // Reclaim space (simplified)
            memmove(entry, entry + 1, (superBlock.rootDirectory.fileCount - i - 1) * sizeof(DirectoryEntry));
            superBlock.rootDirectory.fileCount--;
            return 0; // Success
        }
    }
    return -1; // File not found
}