#include "filesystem.h"
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
     if (argc != 3) {
        fprintf(stderr, "Usage: %s <blockSize> <fileName>\n", argv[0]);
        return 1;
    }

    uint16_t blockSize = (uint16_t)atoi(argv[1]);
    if (blockSize == 0 || blockSize > BLOCK_SIZE) {
        fprintf(stderr, "Invalid block size\n");
        return 1;
    }

    size_t superBlockSize = sizeof(SuperBlock);
    size_t directoryTableSize = sizeof(DirectoryTable);
    size_t freeBlockBitmapSize = sizeof(FreeBlockBitmap);
    
    size_t fatBits = MAX_BLOCKS * FAT_ENTRY_BITS; // Total bits for FAT12
    size_t fatBytes = (fatBits + 7) / 8; // Convert bits to bytes, rounding up

    size_t dataBlocksSize = MAX_BLOCKS * BLOCK_SIZE;
    size_t totalFsSize = superBlockSize + directoryTableSize + freeBlockBitmapSize + fatBytes + dataBlocksSize;

    char *fsMemory = malloc(totalFsSize);
    
    if (!fsMemory) {
        perror("Failed to allocate memory for file system");
        exit(EXIT_FAILURE);
    }

    initializeFileSystem(blockSize, fsMemory, totalFsSize);
    createFile(fsMemory, "example.txt", PERMISSION_READ | PERMISSION_WRITE, "password123");
    // Add more file operations here...
    return 0;
}